"""
Model Base - Menu Microservice

@author - Benjamin Wong Wei En, Hao Jun Poon, Belle Lee, Chen Ziyi, Masturah Binte Sulaiman, Low Louis
@team   - G3T4
"""

from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()